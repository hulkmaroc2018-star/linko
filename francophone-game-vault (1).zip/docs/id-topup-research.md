# ID top-up catalog sources

Reviewed 2026-11-07. Source denominations are catalog references only, not SHOPLAY stock, prices or a supplier integration. Public prices require administrator publication.

- Free Fire Middle East and PUBG Global retain the user's screenshot denominations.
- Mobile Legends: https://www.seagm.com/en-us/mobile-legends-diamonds-top-up and https://www.codashop.com/en-my/mobile-legends. User ID + Zone ID. SEAGM excludes US, Saudi Arabia, Myanmar and Indonesia; SHOPLAY account eligibility remains unconfirmed. Totals include source bonuses; near-identical totals retain separate IDs.
- FC Mobile: https://www.codashop.com/id-id/ea-sports-fc-mobile and https://www.codashop.com/en-my/ea-sports-fc-mobile. UID direct top-up. Points: 40, 100, 520, 1070, 2200, 5750, 12000. Regional storefronts do not establish universal eligibility. https://www.seagm.com/en-us/ea-sports-fc-mobile-fc-points-malaysia instead sells regional redeem codes, not the same ID delivery flow. Legacy EA FC remains separate from FC Mobile; no Silver products were requested.
- COD Mobile Activision: https://www.codashop.com/en-ae/call-of-duty-mobile. Player ID; CP: 80, 420, 880, 2400, 5000, 10800, 21600, 32400, 43200, 54000. UAE storefront does not prove Morocco compatibility; keep region unconfirmed.
- COD Mobile Garena: https://www.seagm.com/garena-call-of-duty-mobile-top-up-my-sg is MY/SG only. Do not merge its CP denominations with Activision. Not added because the user did not specify a Garena region.
- Jawaker: https://www.seagm.com/en-us/jawaker-token. Player Number; tokens: 4250, 32500, 70000, 150000, 230000, 400000, 525000, 805000. Supplier's Global label does not guarantee all-account eligibility. Voucher products are distinct from this delivery method.
- Basha: no verified exact offer or denominations on the cited stores. Mention as unconfirmed inside Jawaker; do not create a priced or purchasable Basha SKU or substitute a similarly named game.

No account passwords are required or collected. Identifier requirements are specifications only; actual recharge fulfillment is not connected.