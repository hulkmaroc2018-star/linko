<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# النجم الهادي

يحصل اللاعبون على رصيد الألعاب وبطاقات الهدايا والاشتراكات التي يريدونها

## المقياس

الطلبات المدفوعة كل أسبوع
