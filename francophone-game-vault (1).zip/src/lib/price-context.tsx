import { createContext, useContext, type ReactNode } from "react";
import { actualPrice, type PriceMap } from "@/lib/prices";
const PriceContext = createContext<PriceMap>({});
export function PriceProvider({ prices, children }: { prices: PriceMap; children: ReactNode }) {
  return <PriceContext.Provider value={prices}>{children}</PriceContext.Provider>;
}
export function usePrices() {
  const prices = useContext(PriceContext);
  return { prices, priceFor: (id: string) => actualPrice(prices, id) };
}