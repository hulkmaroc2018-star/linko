import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { getRequest } from "@tanstack/react-start/server";
import { getSessionUser } from "@/lib/auth.server";

export async function priceAdminClient() {
  const user = await getSessionUser();
  const token = getRequest().headers.get("x-lovable-identity-token");
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!user || !token || !url || !key) return null;
  const client = createClient<Database>(url, key, { accessToken: async () => token, auth: { persistSession: false } });
  return { client, user };
}