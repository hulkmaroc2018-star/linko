export type IdTopupRequirements = {
  identifiers: string[];
  identifiersAr: string[];
  note: string;
  noteAr: string;
};

// These describe delivery requirements, not a connection to a recharge supplier.
export const idTopupRequirements: Record<string, IdTopupRequirements> = {
  ff: { identifiers: ["ID joueur"], identifiersAr: ["معرف اللاعب"], note: "Compte Free Fire Middle East. Aucun mot de passe requis.", noteAr: "حساب فري فاير من منطقة الشرق الأوسط. لا تُطلب كلمة المرور." },
  pubg: { identifiers: ["Player ID"], identifiersAr: ["معرف اللاعب"], note: "PUBG Mobile Global. La version du compte doit être vérifiée avant achat.", noteAr: "ببجي موبايل العالمية. يجب تأكيد إصدار الحساب قبل الشراء." },
  "mobile-legends": { identifiers: ["User ID", "Zone ID"], identifiersAr: ["معرف اللاعب", "معرف المنطقة (Zone ID)"], note: "L’identifiant de zone est distinct du pays du joueur. Aucun mot de passe requis.", noteAr: "معرف المنطقة داخل اللعبة يختلف عن بلد اللاعب. لا تُطلب كلمة المرور." },
  "fc-mobile": { identifiers: ["UID"], identifiersAr: ["معرف اللاعب (UID)"], note: "EA SPORTS FC Mobile uniquement, pas les versions console ou PC. Compatibilité à confirmer.", noteAr: "خاص بإي إيه سبورتس إف سي موبايل، وليس إصدار الكمبيوتر أو أجهزة الألعاب. يجب تأكيد التوافق." },
  cod: { identifiers: ["Player ID"], identifiersAr: ["معرف اللاعب"], note: "La version et la région COD Mobile doivent être confirmées auprès du fournisseur agréé avant achat.", noteAr: "يجب تأكيد إصدار ومنطقة كول أوف ديوتي موبايل مع مزود الشحن المعتمد قبل الشراء." },
  jawaker: { identifiers: ["Player ID"], identifiersAr: ["معرف اللاعب"], note: "Recharge de jetons. L’offre Basha reste à confirmer ; aucun mot de passe requis.", noteAr: "شحن التوكنز. عرض الباشا يحتاج للتأكيد؛ لا تُطلب كلمة المرور." },
};