export function addCartQuantity(cart: Record<string, number>, id: string, quantity = 1) {
  if (!Number.isSafeInteger(quantity) || quantity < 1) return cart;
  return { ...cart, [id]: (cart[id] ?? 0) + quantity };
}