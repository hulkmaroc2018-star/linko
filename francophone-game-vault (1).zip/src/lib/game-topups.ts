// Denominations from the supplied reference screenshots; no competitor prices.
export const gameTopupInfo: Record<string, { name: string; nameAr: string; flag: string }> = {
  ff: { name: "Middle East · ID joueur", nameAr: "الشرق الأوسط · معرف اللاعب", flag: "🌍" },
  pubg: { name: "Global", nameAr: "عالمية", flag: "🌐" },
  "mobile-legends": { name: "Région à confirmer · ID + Zone ID", nameAr: "المنطقة تحتاج للتأكيد · ID + Zone ID", flag: "🌍" },
  "fc-mobile": { name: "Région à confirmer · UID", nameAr: "المنطقة تحتاج للتأكيد · UID", flag: "🌍" },
  cod: { name: "Activision · région à confirmer", nameAr: "أكتيفيجن · المنطقة تحتاج للتأكيد", flag: "🌍" },
  jawaker: { name: "Compatibilité à confirmer · Player Number", nameAr: "التوافق يحتاج للتأكيد · رقم اللاعب", flag: "🌍" },
};

export const researchedIdGames = [
  { id: "mobile-legends", name: "Mobile Legends: Bang Bang", nameAr: "موبايل ليجندز: بانغ بانغ", unit: "diamants", unitAr: "ألماسة", amounts: [14, 42, 55, 70, 86, 140, 165, 172, 257, 275, 284, 344, 355, 429, 565, 706, 716, 1084, 1160, 1346, 1446, 1770, 1825, 2195, 2975, 2976, 3688, 5532, 6000, 7502, 9288], legacyAmount: 14, emoji: "⚔️", hue: 140 },
  { id: "fc-mobile", name: "EA SPORTS FC Mobile", nameAr: "إي إيه سبورتس إف سي موبايل", unit: "FC Points", unitAr: "FC Points", amounts: [40, 100, 520, 1070, 2200, 5750, 12000], legacyAmount: 40, emoji: "⚽", hue: 160 },
  { id: "cod", name: "Call of Duty Mobile (Activision)", nameAr: "كول أوف ديوتي موبايل (أكتيفيجن)", unit: "CP", unitAr: "CP", amounts: [80, 420, 880, 2400, 5000, 10800, 21600, 32400, 43200, 54000], legacyAmount: 880, emoji: "🎯", hue: 140 },
  { id: "jawaker", name: "Jawaker", nameAr: "جواكر", unit: "tokens", unitAr: "توكنز", amounts: [4250, 32500, 70000, 150000, 230000, 400000, 525000, 805000], legacyAmount: 4250, emoji: "🃏", hue: 140 },
];

const freeFireAmounts = [50, 100, 210, 530, 1080, 2200];
const pubgAmounts = [
  { amount: 60, label: "60 UC" },
  { amount: 325, label: "300 + 25 UC" },
  { amount: 660, label: "600 + 60 UC" },
  { amount: 1800, label: "1500 + 300 UC" },
  { amount: 3850, label: "3000 + 850 UC" },
  { amount: 8100, label: "6000 + 2100 UC" },
  { amount: 16200, label: "12000 + 4200 UC" },
];

export const gameTopupProducts = [
  ...researchedIdGames.flatMap((game) => game.amounts.map((amount) => ({
    id: amount === game.legacyAmount ? game.id : `${game.id}-${amount}`, productId: game.id, familyId: game.id,
    name: `${game.name} ${amount} ${game.unit}`, nameAr: `${game.nameAr} ${amount} ${game.unitAr}`,
    cat: "games" as const, price: game.id === "cod" && amount === 880 ? 109 : 0, emoji: game.emoji, hue: game.hue,
  }))),
  ...freeFireAmounts.map((amount) => ({
    id: amount === 530 ? "ff" : `ff-${amount}`, productId: "ff", familyId: "ff",
    name: `Free Fire (Middle East) ${amount} diamants`, nameAr: `فري فاير (الشرق الأوسط) ${amount} جوهرة`,
    cat: "games" as const, price: amount === 530 ? 49 : 0, emoji: "🔥", hue: 40,
  })),
  ...pubgAmounts.map(({ amount, label }) => ({
    id: amount === 660 ? "pubg" : `pubg-${amount}`, productId: "pubg", familyId: "pubg",
    name: `PUBG Mobile (Global) ${label}`, nameAr: `ببجي موبايل (عالمية) ${label}`,
    cat: "games" as const, price: amount === 660 ? 99 : 0, emoji: "🪖", hue: 85,
  })),
];

export const gameTopupDetails = Object.fromEntries(gameTopupProducts.map((item) => {
  const researched = researchedIdGames.find((game) => game.id === item.productId);
  if (researched) {
    const amount = item.name.match(/(\d+) \S+(?: \S+)?$/)?.[1] ?? "";
    return [item.id, {
      brand: researched.name,
      format: `${amount} ${researched.unit}`, formatAr: `${amount} ${researched.unitAr}`,
      description: `Recharge ${researched.unit} pour ${researched.name}. Région, compatibilité et disponibilité à confirmer avant achat.`,
      descriptionAr: `شحن ${researched.unitAr} للعبة ${researched.nameAr}. المنطقة، توافق الحساب والتوفر تحتاج للتأكيد قبل الشراء.`,
    }];
  }
  const ff = item.productId === "ff";
  const format = item.name.replace(/^.*\) /, "");
  return [item.id, {
    brand: ff ? "Free Fire (Middle East)" : "PUBG Mobile UC (Global)",
    format, formatAr: ff ? format.replace("diamants", "جوهرة") : format,
    description: ff ? "Recharge de diamants Free Fire pour un ID joueur de la région Middle East. Compatibilité et disponibilité à confirmer avant achat." : "Recharge UC pour PUBG Mobile Global. Compatibilité du compte et disponibilité à confirmer avant achat.",
    descriptionAr: ff ? "شحن جواهر فري فاير لمعرف لاعب من منطقة الشرق الأوسط. يجب تأكيد توافق الحساب والتوفر قبل الشراء." : "شحن شدات ببجي موبايل العالمية. يجب تأكيد توافق الحساب والتوفر قبل الشراء.",
  }];
}));