import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "fr" | "ar";

const dict = {
  fr: {
    tagline: "Cartes cadeaux & recharges de jeux, livrées en quelques secondes.",
    title: "Rechargez. Jouez. Gagnez.",
    shop: "Voir la boutique",
    all: "Tout",
    cards: "Cartes",
    topup: "Recharges",
    add: "Ajouter",
    cart: "Panier",
    empty: "Votre panier est vide.",
    total: "Total",
    checkout: "Commander",
    soon: "Le paiement en ligne arrive bientôt !",
    playerId: "ID joueur requis",
    instant: "Livraison instantanée",
    secure: "Paiement sécurisé",
    support: "Support 7j/7",
    remove: "Retirer",
    footer: "Tous droits réservés.",
    home: "Accueil",
    gifts: "Cartes cadeaux",
    subs: "Abonnements",
    games: "Recharges de jeux",
    giftsSub: "PSN, Steam, Google Play, Xbox… codes livrés instantanément.",
    subsSub: "Spotify, Netflix, Shahid, Game Pass… activez en un clic.",
  },
  ar: {
    tagline: "بطاقات هدايا وشحن ألعاب، تُسلَّم في ثوانٍ.",
    title: "اشحن. العب. اربح.",
    shop: "تصفح المتجر",
    all: "الكل",
    cards: "بطاقات",
    topup: "شحن",
    add: "أضف",
    cart: "السلة",
    empty: "سلتك فارغة.",
    total: "المجموع",
    checkout: "اطلب الآن",
    soon: "الدفع الإلكتروني قريباً!",
    playerId: "يتطلب معرف اللاعب",
    instant: "تسليم فوري",
    secure: "دفع آمن",
    support: "دعم 7/7",
    remove: "حذف",
    footer: "جميع الحقوق محفوظة.",
    home: "الرئيسية",
    gifts: "بطاقات الهدايا",
    subs: "الاشتراكات",
    games: "شحن الألعاب",
    giftsSub: "بلايستيشن، ستيم، جوجل بلاي، إكس بوكس… أكواد فورية.",
    subsSub: "سبوتيفاي، نتفليكس، شاهد، جيم باس… فعّل بنقرة.",
  },
};

export type Key = keyof typeof dict.fr;
const Ctx = createContext<{ lang: Lang; setLang: (l: Lang) => void; t: (k: Key) => string }>({
  lang: "fr",
  setLang: () => {},
  t: (k) => dict.fr[k],
});

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>("fr");
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  }, [lang]);
  return <Ctx.Provider value={{ lang, setLang, t: (k) => dict[lang][k] }}>{children}</Ctx.Provider>;
}

export const useLang = () => useContext(Ctx);
