import { createServerFn } from "@tanstack/react-start";
import { queryOptions } from "@tanstack/react-query";
import { validPrice } from "@/lib/prices";
import { products } from "@/lib/store";

export const readPrices = createServerFn({ method: "GET" }).handler(async () => {
  const { createClient } = await import("@supabase/supabase-js");
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) throw new Error("Service indisponible");
  const client = createClient(url, key, { auth: { persistSession: false }, global: { fetch: (input, init) => {
    const headers = new Headers(init?.headers); headers.delete("Authorization"); headers.set("apikey", key); return fetch(input, { ...init, headers });
  } } });
  const { data, error } = await client.from("published_prices").select("format_id,price");
  if (error) throw new Error("Prix indisponibles");
  return Object.fromEntries((data ?? []).map((row) => [row.format_id as string, Number(row.price)]));
});
export const priceQuery = queryOptions({ queryKey: ["published-prices"], queryFn: () => readPrices(), staleTime: 0 });

export const adminPrices = createServerFn({ method: "GET" }).handler(async () => {
  const { priceAdminClient } = await import("@/lib/prices.server");
  const access = await priceAdminClient();
  if (!access) return { allowed: false as const, userId: null, drafts: [], published: [] };
  const { client, user } = access;
  const { data: roles, error: roleError } = await client.from("user_roles").select("role").eq("user_id", user.userId);
  if (roleError || !roles?.some((row) => row.role === "admin")) return { allowed: false as const, userId: user.userId, drafts: [], published: [] };
  const [drafts, published] = await Promise.all([client.from("price_drafts").select("*"), client.from("published_prices").select("*")]);
  if (drafts.error || published.error) throw new Error("Chargement impossible");
  return { allowed: true as const, userId: user.userId, drafts: drafts.data ?? [], published: published.data ?? [] };
});

export const changePrice = createServerFn({ method: "POST" }).inputValidator((input: { id: string; action: "save" | "publish" | "hide"; price?: number | undefined }) => {
  if (!products.some((item) => item.id === input.id) || !["save", "publish", "hide"].includes(input.action)) throw new Error("Produit invalide");
  if (input.action === "save" && (typeof input.price !== "number" || !validPrice(input.price))) throw new Error("Prix invalide");
  return input;
}).handler(async ({ data }) => {
  const { priceAdminClient } = await import("@/lib/prices.server");
  const access = await priceAdminClient();
  if (!access) throw new Error("Accès refusé");
  const { client, user } = access;
  const { data: roles, error: roleError } = await client.from("user_roles").select("role").eq("user_id", user.userId);
  if (roleError || !roles?.some((row) => row.role === "admin")) throw new Error("Accès refusé");
  if (data.action === "save" && typeof data.price !== "number") throw new Error("Prix invalide");
  const result = data.action === "save" && typeof data.price === "number" ? await client.from("price_drafts").upsert({ format_id: data.id, price: data.price, updated_by: user.userId, updated_at: new Date().toISOString() }) : await client.rpc(data.action === "publish" ? "publish_price" : "unpublish_price", { _format_id: data.id });
  if (result.error) throw new Error("Modification impossible");
  return { ok: true };
});