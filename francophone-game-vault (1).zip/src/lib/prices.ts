export type PriceMap = Record<string, number>;
export function actualPrice(prices: PriceMap, id: string) {
  const price = prices[id];
  return typeof price === "number" && Number.isFinite(price) && price > 0 ? price : null;
}
export function validPrice(value: number) {
  return Number.isFinite(value) && value > 0 && value <= 9999999999.99 && Math.abs(value * 100 - Math.round(value * 100)) < 0.00001;
}