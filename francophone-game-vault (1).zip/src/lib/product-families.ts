type CatalogItem = { id: string; productId?: string; familyId?: string };

export const productFamilies = [
  { id: "free-fire", name: "Free Fire", nameAr: "فري فاير", productIds: ["ff"] },
  { id: "pubg", name: "PUBG Mobile", nameAr: "ببجي موبايل", productIds: ["pubg"] },
  { id: "mobile-legends", name: "Mobile Legends: Bang Bang", nameAr: "موبايل ليجندز: بانغ بانغ", productIds: ["mobile-legends"] },
  { id: "cod", name: "Call of Duty Mobile", nameAr: "كول أوف ديوتي موبايل", productIds: ["cod"] },
  { id: "ea-fc", name: "EA SPORTS FC", nameAr: "إي إيه سبورتس إف سي", productIds: ["fc-mobile", "fc"] },
  { id: "jawaker", name: "Jawaker", nameAr: "جواكر", productIds: ["jawaker"] },
  { id: "fortnite", name: "Fortnite", nameAr: "فورتنايت", productIds: ["fortnite"] },
  { id: "roblox", name: "Roblox", nameAr: "روبلوكس", productIds: ["roblox"] },
  { id: "playstation", name: "PlayStation · PSN", nameAr: "بلايستيشن · PSN", productIds: ["psn", "psplus"] },
  { id: "steam", name: "Steam", nameAr: "ستيم", productIds: ["steam"] },
  { id: "google-play", name: "Google Play", nameAr: "جوجل بلاي", productIds: ["gplay"] },
  { id: "xbox", name: "Xbox", nameAr: "إكس بوكس", productIds: ["xbox", "gamepass"] },
  { id: "app-store", name: "App Store", nameAr: "آب ستور", productIds: ["itunes"] },
  { id: "nintendo", name: "Nintendo eShop", nameAr: "نينتندو إي شوب", productIds: ["nintendo"] },
  { id: "spotify", name: "Spotify", nameAr: "سبوتيفاي", productIds: ["spotify"] },
  { id: "netflix", name: "Netflix", nameAr: "نتفليكس", productIds: ["netflix"] },
  { id: "shahid", name: "Shahid", nameAr: "شاهد", productIds: ["shahid"] },
  { id: "youtube", name: "YouTube", nameAr: "يوتيوب", productIds: ["youtube"] },
];

export function groupProductsByFamily<T extends CatalogItem>(items: T[]) {
  return productFamilies.map((family) => ({
    ...family,
    products: items.filter((product) => family.productIds.includes(product.familyId ?? product.productId ?? product.id)),
  })).filter((family) => family.products.length > 0);
}