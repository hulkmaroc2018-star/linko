import { createContext, useContext, useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { useLang } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { addCartQuantity } from "@/lib/cart-quantity";
import { productDetails } from "@/lib/product-details";
import { groupProductsByFamily } from "@/lib/product-families";
import { groupProductFormats } from "@/lib/product-options";
import { regionalProducts, regionalInfo } from "@/lib/regional-catalog";
import { gameTopupProducts, gameTopupInfo } from "@/lib/game-topups";
import { usePrices } from "@/lib/price-context";
import gamesImage from "@/assets/offers-games.jpg";
import giftsImage from "@/assets/offers-gifts.jpg";
import subscriptionsImage from "@/assets/offers-subscriptions.jpg";

export type Category = "games" | "gifts" | "subs";
export type Product = { id: string; productId?: string; familyId?: string; name: string; nameAr: string; cat: Category; price: number; emoji: string; hue: number };

export const products: Product[] = [
  ...regionalProducts,
  ...gameTopupProducts,
  { id: "fc", name: "EA FC 1050 Points", nameAr: "إي إيه إف سي 1050 نقطة", cat: "games", price: 119, emoji: "⚽", hue: 160 },
  { id: "fortnite", name: "Fortnite 1000 V-Bucks", nameAr: "فورتنايت 1000 في-باكس", cat: "games", price: 95, emoji: "🦙", hue: 290 },
  { id: "roblox", name: "Roblox 800 Robux", nameAr: "روبلوكس 800 روبوكس", cat: "games", price: 110, emoji: "🧱", hue: 20 },
  { id: "psn", name: "PSN 20 €", nameAr: "بطاقة بلايستيشن 20 يورو", cat: "gifts", price: 229, emoji: "🎮", hue: 255 },
  { id: "psn-10", productId: "psn", name: "PSN 10 €", nameAr: "بطاقة بلايستيشن 10 يورو", cat: "gifts", price: 119, emoji: "🎮", hue: 255 },
  { id: "psn-50", productId: "psn", name: "PSN 50 €", nameAr: "بطاقة بلايستيشن 50 يورو", cat: "gifts", price: 569, emoji: "🎮", hue: 255 },
  { id: "steam", name: "Steam 10 €", nameAr: "ستيم 10 يورو", cat: "gifts", price: 119, emoji: "💨", hue: 230 },
  { id: "gplay", name: "Google Play 100 DH", nameAr: "جوجل بلاي 100 درهم", cat: "gifts", price: 105, emoji: "▶️", hue: 150 },
  { id: "xbox", name: "Xbox 15 €", nameAr: "إكس بوكس 15 يورو", cat: "gifts", price: 175, emoji: "🟢", hue: 135 },
  { id: "itunes", name: "App Store 15 €", nameAr: "آب ستور 15 يورو", cat: "gifts", price: 175, emoji: "🍎", hue: 0 },
  { id: "nintendo", name: "Nintendo eShop 15 €", nameAr: "نينتندو 15 يورو", cat: "gifts", price: 175, emoji: "🍄", hue: 25 },
  { id: "spotify", name: "Spotify Premium 1 mois", nameAr: "سبوتيفاي بريميوم شهر", cat: "subs", price: 59, emoji: "🎧", hue: 145 },
  { id: "netflix", name: "Netflix 1 mois", nameAr: "نتفليكس شهر", cat: "subs", price: 89, emoji: "🎬", hue: 25 },
  { id: "shahid", name: "Shahid VIP 1 mois", nameAr: "شاهد VIP شهر", cat: "subs", price: 49, emoji: "📺", hue: 190 },
  { id: "gamepass", name: "Xbox Game Pass Ultimate", nameAr: "جيم باس ألتيميت", cat: "subs", price: 149, emoji: "🕹️", hue: 135 },
  { id: "psplus", name: "PS Plus Essential 1 mois", nameAr: "بلايستيشن بلس شهر", cat: "subs", price: 99, emoji: "➕", hue: 60 },
  { id: "youtube", name: "YouTube Premium 1 mois", nameAr: "يوتيوب بريميوم شهر", cat: "subs", price: 45, emoji: "▶", hue: 20 },
];

type CartCtx = { cart: Record<string, number>; add: (id: string, quantity?: number) => void; remove: (id: string) => void; open: boolean; setOpen: (o: boolean) => void };
const Ctx = createContext<CartCtx | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const { priceFor } = usePrices();
  const [cart, setCart] = useState<Record<string, number>>({});
  const [open, setOpen] = useState(false);
  return (
    <Ctx.Provider
      value={{
        cart,
        open,
        setOpen,
        add: (id, quantity = 1) => setCart((c) => products.some((p) => p.id === id) && priceFor(id) !== null ? addCartQuantity(c, id, quantity) : c),
        remove: (id) => setCart(({ [id]: _, ...rest }) => rest),
      }}
    >
      {children}
    </Ctx.Provider>
  );
}
export const useCart = () => {
  const context = useContext(Ctx);
  if (!context) throw new Error("CartProvider is required");
  return context;
};


export function Header() {
  const { lang, setLang, t } = useLang();
  const { cart, setOpen } = useCart();
  const count = Object.values(cart).reduce((a, b) => a + b, 0);
  return (
    <header className="sticky top-0 z-20 border-b border-border bg-background/80 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link to="/" className="font-display text-xl font-bold">
          SHOP<span className="text-primary">LAY</span>
        </Link>
        <div className="flex items-center gap-1 sm:gap-2">
          <MenuDropdown />
          <Button variant="ghost" size="sm" asChild><Link to="/admin">{lang === "ar" ? "الإدارة" : "Admin"}</Link></Button>
          <button onClick={() => setLang(lang === "fr" ? "ar" : "fr")} className="rounded-full border border-border px-3 py-1.5 text-sm hover:border-primary">
            {lang === "fr" ? "العربية" : "FR"}
          </button>
          <button onClick={() => setOpen(true)} className="rounded-full bg-primary px-2 py-1.5 text-sm font-semibold text-primary-foreground sm:px-4">
            {t("cart")} {count > 0 && <span className="ms-1 rounded-full bg-background px-1.5 text-xs text-foreground">{count}</span>}
          </button>
        </div>
      </div>
    </header>
  );
}

const sections: { cat: Category; to: "/" | "/cartes-cadeaux" | "/abonnements"; key: "games" | "gifts" | "subs" }[] = [
  { cat: "games", to: "/", key: "games" },
  { cat: "gifts", to: "/cartes-cadeaux", key: "gifts" },
  { cat: "subs", to: "/abonnements", key: "subs" },
];

function MenuDropdown() {
  const { lang, t } = useLang();
  const [open, setOpen] = useState(false);
  const [section, setSection] = useState<Category | null>("games");
  return (
    <div>
      <button onClick={() => setOpen(!open)} className="rounded-full border border-border px-3 py-1.5 text-sm hover:border-primary" aria-label="Menu">
        ☰
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute inset-x-3 top-full z-20 mt-1 max-h-[75vh] md:inset-x-auto md:end-4 md:w-72 overflow-auto rounded-2xl border border-border bg-card p-2 shadow-neon">
            <Link to="/" onClick={() => setOpen(false)} className="block rounded-xl px-3 py-2 font-semibold hover:bg-secondary">{t("home")}</Link>
            {sections.map((s) => (
              <div key={s.cat}>
                <button onClick={() => setSection(section === s.cat ? null : s.cat)} className="flex w-full items-center justify-between rounded-xl px-3 py-2 font-semibold hover:bg-secondary">
                  {t(s.key)}
                  <span className="text-muted-foreground">{section === s.cat ? "−" : "+"}</span>
                </button>
                {section === s.cat && (
                  <div className="mb-1 ms-3 border-s border-border ps-2">
                    {groupProductsByFamily(products.filter((p) => p.cat === s.cat)).map((family) => (
                      <div key={family.id} className="py-1">
                        <p className="px-3 py-1 text-xs font-semibold text-primary">{lang === "ar" ? family.nameAr : family.name}</p>
                        {groupProductFormats(family.products).map((p) => (
                      <Link key={p.id} to="/produits/$productId" params={{ productId: p.id }} onClick={() => setOpen(false)} className="block rounded-lg px-3 py-1.5 text-sm text-muted-foreground hover:bg-secondary hover:text-foreground">
                        {lang === "ar" ? p.nameAr : p.name}
                      </Link>
                        ))}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export function ProductGrid({ cat, compact = false }: { cat?: Category; compact?: boolean }) {
  const { lang } = useLang();
  const { priceFor } = usePrices();
  return (
    <div className="grid grid-cols-3 gap-2 sm:gap-4">
      {groupProductsByFamily(products.filter((p) => !cat || p.cat === cat)).map((family) => (
        <section key={family.id} aria-labelledby={`family-${family.id}`} className="contents">
          <h3 id={`family-${family.id}`} className="sr-only">{lang === "ar" ? family.nameAr : family.name}</h3>
          <div className="contents">
      {groupProductFormats(family.products).map((group) => {
        const p = group.formats[0];
        if (!p) return null;
        const actual = group.formats.map((format) => priceFor(format.id)).filter((price): price is number => price !== null);
        const price = actual.length ? Math.min(...actual) : null;
        const region = gameTopupInfo[group.id] ?? regionalInfo[group.id];
        return (
        <div key={p.id} id={p.id} className="scroll-mt-24 overflow-hidden rounded-lg border border-border bg-card transition hover:-translate-y-1 hover:border-primary">
          <Link to="/produits/$productId" params={{ productId: p.id }} aria-label={lang === "ar" ? p.nameAr : p.name} className={`relative flex items-end overflow-hidden bg-secondary ${compact ? "aspect-square sm:aspect-[2/1]" : "aspect-[4/3]"}`}>
            <img src={p.cat === "games" ? gamesImage : p.cat === "gifts" ? giftsImage : subscriptionsImage} alt="" width={1536} height={768} loading="lazy" className="absolute inset-0 h-full w-full object-cover object-right" />
            {region && <span className="absolute end-1 top-1 rounded-sm bg-background/90 px-1 text-sm">{region.flag}</span>}
          </Link>
          <div className="min-w-0 p-2 sm:p-3">
            <h4 className="break-words text-xs font-semibold sm:text-sm"><Link to="/produits/$productId" params={{ productId: group.id }} className="hover:text-primary">{lang === "ar" ? group.nameAr : group.name}</Link></h4>
            <p className="mt-1 break-words text-xs text-muted-foreground">{region ? (lang === "ar" ? region.nameAr : region.name) : (lang === "ar" ? "المنطقة تحتاج للتأكيد" : "Région à confirmer")}</p>
            {!compact && <p className="mt-1 break-words text-xs text-muted-foreground">{group.formats.map((format) => lang === "ar" ? productDetails[format.id]?.formatAr : productDetails[format.id]?.format).join(" · ")}</p>}
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
              <span className="font-display text-xs font-bold text-primary sm:text-base">{price === null ? (lang === "ar" ? "قريباً" : "Bientôt") : <>{group.formats.length > 1 && (lang === "ar" ? "من " : "Dès ")}{price} DH</>}</span>
              <Button variant="secondary" size="sm" asChild>
                <Link to="/produits/$productId" params={{ productId: group.id }}>{lang === "ar" ? "اختيار" : "Choisir"}</Link>
              </Button>
            </div>
          </div>
        </div>
      ); })}
          </div>
        </section>
      ))}
    </div>
  );
}

export function PageTitle({ title, sub }: { title: string; sub: string }) {
  return (
    <section className="hero-glow">
      <div className="mx-auto max-w-6xl px-4 py-14 text-center">
        <h1 className="font-display text-3xl font-bold md:text-5xl">{title}</h1>
        <p className="mx-auto mt-3 max-w-xl text-muted-foreground">{sub}</p>
      </div>
    </section>
  );
}

export function CartDrawer() {
  const { lang, t } = useLang();
  const { priceFor } = usePrices();
  const { cart, remove, open, setOpen } = useCart();
  if (!open) return null;
  const items = Object.entries(cart);
  const total = items.reduce((s, [id, q]) => s + q * (priceFor(id) ?? 0), 0);
  const unavailable = items.some(([id]) => priceFor(id) === null);
  return (
    <div className="fixed inset-0 z-30 flex justify-end bg-background/70" onClick={() => setOpen(false)}>
      <aside className="flex h-full w-full max-w-sm flex-col border-s border-border bg-card p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h2 className="font-display text-xl font-bold">{t("cart")}</h2>
          <button onClick={() => setOpen(false)} className="text-2xl text-muted-foreground">×</button>
        </div>
        <div className="mt-4 flex-1 space-y-3 overflow-auto">
          {items.length === 0 && <p className="text-muted-foreground">{t("empty")}</p>}
          {items.map(([id, q]) => {
            const p = products.find((x) => x.id === id);
            if (!p) return null;
            return (
              <div key={id} className="flex items-center justify-between rounded-xl bg-secondary p-3 text-sm">
                <div>
                  <div className="font-medium">{lang === "ar" ? p.nameAr : p.name}</div>
                  <div className="text-muted-foreground">{priceFor(id) === null ? (lang === "ar" ? "غير متاح" : "Indisponible") : `${q} × ${priceFor(id)} DH`}</div>
                </div>
                <button onClick={() => remove(id)} className="text-xs text-destructive">{t("remove")}</button>
              </div>
            );
          })}
        </div>
        <div className="border-t border-border pt-4">
          <div className="flex justify-between font-bold"><span>{t("total")}</span><span className="text-primary">{unavailable ? (lang === "ar" ? "غير متاح" : "Indisponible") : `${total} DH`}</span></div>
          <button disabled={!items.length || unavailable} onClick={() => alert(t("soon"))} className="mt-4 w-full rounded-full bg-primary py-3 font-semibold text-primary-foreground disabled:opacity-40">
            {t("checkout")}
          </button>
        </div>
      </aside>
    </div>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const { lang, t } = useLang();
  return (
    <div className={`min-h-screen ${lang === "ar" ? "font-arabic" : "font-sans"}`}>
      <Header />
      {children}
      <footer className="border-t border-border py-8 text-center text-sm text-muted-foreground">© 2026 SHOPLAY · {t("footer")}</footer>
      <CartDrawer />
    </div>
  );
}
