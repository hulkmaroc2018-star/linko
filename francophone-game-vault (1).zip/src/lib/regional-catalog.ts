// Demonstration SKUs only: regions describe the example product, not verified stock.
export const regionalProducts = [
  { id: "psn-fr", productId: "psn-fr", familyId: "psn", name: "PSN (FR) 20 €", nameAr: "بلايستيشن (FR) 20 يورو", cat: "gifts" as const, price: 229, emoji: "🎮", hue: 255 },
  { id: "psn-fr-10", productId: "psn-fr", familyId: "psn", name: "PSN (FR) 10 €", nameAr: "بلايستيشن (FR) 10 يورو", cat: "gifts" as const, price: 119, emoji: "🎮", hue: 255 },
  { id: "psn-fr-50", productId: "psn-fr", familyId: "psn", name: "PSN (FR) 50 €", nameAr: "بلايستيشن (FR) 50 يورو", cat: "gifts" as const, price: 569, emoji: "🎮", hue: 255 },
  { id: "psn-us", productId: "psn-us", familyId: "psn", name: "PSN (US) 20 $", nameAr: "بلايستيشن (US) 20 دولار", cat: "gifts" as const, price: 209, emoji: "🎮", hue: 255 },
  { id: "psn-us-10", productId: "psn-us", familyId: "psn", name: "PSN (US) 10 $", nameAr: "بلايستيشن (US) 10 دولار", cat: "gifts" as const, price: 109, emoji: "🎮", hue: 255 },
  { id: "psn-us-50", productId: "psn-us", familyId: "psn", name: "PSN (US) 50 $", nameAr: "بلايستيشن (US) 50 دولار", cat: "gifts" as const, price: 519, emoji: "🎮", hue: 255 },
];

export const regionalInfo: Record<string, { name: string; nameAr: string; flag: string }> = {
  "psn-fr": { name: "France", nameAr: "فرنسا", flag: "🇫🇷" },
  "psn-us": { name: "États-Unis", nameAr: "الولايات المتحدة", flag: "🇺🇸" },
};

export const regionalDetails = Object.fromEntries(regionalProducts.map((item) => {
  const us = item.productId === "psn-us";
  const value = item.id.endsWith("-10") ? 10 : item.id.endsWith("-50") ? 50 : 20;
  return [item.id, {
    brand: `PSN (${us ? "US" : "FR"})`,
    format: `${value} ${us ? "$" : "€"}`,
    formatAr: `${value} ${us ? "دولار" : "يورو"}`,
    description: `Carte PlayStation pour un compte ${us ? "américain" : "français"}. Produit et prix de démonstration ; disponibilité à confirmer.`,
    descriptionAr: `بطاقة بلايستيشن لحساب ${us ? "أمريكي" : "فرنسي"}. المنتج والسعر تجريبيان؛ التوفر يحتاج للتأكيد.`,
  }];
}));