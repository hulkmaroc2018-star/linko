import { regionalDetails } from "@/lib/regional-catalog";
import { gameTopupDetails } from "@/lib/game-topups";

type Details = { brand: string; format: string; formatAr: string; description: string; descriptionAr: string };

export const productDetails: Record<string, Details> = {
  ...regionalDetails,
  ...gameTopupDetails,
  fc: { brand: "EA SPORTS FC", format: "1 050 Points", formatAr: "1050 نقطة", description: "Points pour EA SPORTS FC. Édition et plateforme à confirmer.", descriptionAr: "نقاط للعبة إي إيه سبورتس إف سي؛ الإصدار والمنصة يحتاجان للتأكيد." },
  fortnite: { brand: "Fortnite", format: "1 000 V-Bucks", formatAr: "1000 في-باكس", description: "V-Bucks pour Fortnite. Mode d’activation à confirmer.", descriptionAr: "في-باكس للعبة فورتنايت؛ طريقة التفعيل تحتاج للتأكيد." },
  roblox: { brand: "Roblox", format: "800 Robux", formatAr: "800 روبوكس", description: "Robux pour Roblox. Mode d’activation à confirmer.", descriptionAr: "روبوكس للعبة روبلوكس؛ طريقة التفعيل تحتاج للتأكيد." },
  psn: { brand: "PlayStation", format: "20 €", formatAr: "20 يورو", description: "Crédit pour le PlayStation Store. Région du code à confirmer.", descriptionAr: "رصيد لمتجر بلايستيشن؛ منطقة الكود تحتاج للتأكيد." },
  "psn-10": { brand: "PlayStation", format: "10 €", formatAr: "10 يورو", description: "Crédit pour le PlayStation Store. Région du code à confirmer.", descriptionAr: "رصيد لمتجر بلايستيشن؛ منطقة الكود تحتاج للتأكيد." },
  "psn-50": { brand: "PlayStation", format: "50 €", formatAr: "50 يورو", description: "Crédit pour le PlayStation Store. Région du code à confirmer.", descriptionAr: "رصيد لمتجر بلايستيشن؛ منطقة الكود تحتاج للتأكيد." },
  steam: { brand: "Steam", format: "10 €", formatAr: "10 يورو", description: "Crédit pour le portefeuille Steam. Compatibilité du compte à confirmer.", descriptionAr: "رصيد لمحفظة ستيم؛ توافق الحساب يحتاج للتأكيد." },
  gplay: { brand: "Google Play", format: "100 DH", formatAr: "100 درهم", description: "Carte Google Play du catalogue de démonstration. Devise et région d’activation à confirmer.", descriptionAr: "بطاقة جوجل بلاي من الكتالوج التجريبي؛ عملة ومنطقة التفعيل تحتاجان للتأكيد." },
  xbox: { brand: "Xbox", format: "15 €", formatAr: "15 يورو", description: "Crédit Xbox / Microsoft Store. Région du code à confirmer.", descriptionAr: "رصيد إكس بوكس / متجر مايكروسوفت؛ منطقة الكود تحتاج للتأكيد." },
  itunes: { brand: "App Store", format: "15 €", formatAr: "15 يورو", description: "Carte App Store. Pays du compte Apple à confirmer.", descriptionAr: "بطاقة آب ستور؛ بلد حساب آبل يحتاج للتأكيد." },
  nintendo: { brand: "Nintendo eShop", format: "15 €", formatAr: "15 يورو", description: "Crédit Nintendo eShop. Région du compte à confirmer.", descriptionAr: "رصيد نينتندو إي شوب؛ منطقة الحساب تحتاج للتأكيد." },
  spotify: { brand: "Spotify Premium", format: "1 mois", formatAr: "شهر واحد", description: "Abonnement Spotify Premium. Type d’offre et activation à confirmer.", descriptionAr: "اشتراك سبوتيفاي بريميوم؛ نوع العرض والتفعيل يحتاجان للتأكيد." },
  netflix: { brand: "Netflix", format: "1 mois", formatAr: "شهر واحد", description: "Abonnement Netflix. Formule et activation à confirmer.", descriptionAr: "اشتراك نتفليكس؛ الباقة والتفعيل يحتاجان للتأكيد." },
  shahid: { brand: "Shahid VIP", format: "1 mois", formatAr: "شهر واحد", description: "Abonnement Shahid VIP. Conditions d’activation à confirmer.", descriptionAr: "اشتراك شاهد VIP؛ شروط التفعيل تحتاج للتأكيد." },
  gamepass: { brand: "Xbox Game Pass", format: "Ultimate · durée à confirmer", formatAr: "ألتيميت · المدة تحتاج للتأكيد", description: "Xbox Game Pass Ultimate. Durée, région et conditions d’activation à confirmer.", descriptionAr: "إكس بوكس جيم باس ألتيميت؛ المدة والمنطقة وشروط التفعيل تحتاج للتأكيد." },
  psplus: { brand: "PlayStation Plus", format: "Essential · 1 mois", formatAr: "إسنشال · شهر واحد", description: "PlayStation Plus Essential. Région et activation à confirmer.", descriptionAr: "بلايستيشن بلس إسنشال؛ المنطقة والتفعيل يحتاجان للتأكيد." },
  youtube: { brand: "YouTube Premium", format: "1 mois", formatAr: "شهر واحد", description: "Abonnement YouTube Premium. Type d’offre et activation à confirmer.", descriptionAr: "اشتراك يوتيوب بريميوم؛ نوع العرض والتفعيل يحتاجان للتأكيد." },
};