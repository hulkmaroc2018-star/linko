import { productDetails } from "@/lib/product-details";

type FormatItem = { id: string; productId?: string; name: string; nameAr: string; price: number };

export function getProductId(item: { id: string; productId?: string }) {
  return item.productId ?? item.id;
}

export function groupProductFormats<T extends FormatItem>(items: T[]) {
  const groups = new Map<string, { id: string; name: string; nameAr: string; formats: T[] }>();
  for (const item of items) {
    const id = getProductId(item);
    const existing = groups.get(id);
    if (existing) existing.formats.push(item);
    else groups.set(id, {
      id,
      name: productDetails[id]?.brand ?? item.name,
      nameAr: item.nameAr.replace(/\s+(?:\d.*|شهر.*|ألتيميت.*)$/, ""),
      formats: [item],
    });
  }
  return [...groups.values()];
}