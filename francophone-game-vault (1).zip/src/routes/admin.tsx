import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Save, Upload, EyeOff, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { adminPrices, changePrice } from "@/lib/prices.functions";
import { products } from "@/lib/store";
import { useLang } from "@/lib/i18n";
import { validPrice } from "@/lib/prices";

export const Route = createFileRoute("/admin")({ head: () => ({ meta: [{ title: "Administration des prix — SHOPLAY" }, { name: "description", content: "Gestion privée des prix réels des formats et régions SHOPLAY." }, { property: "og:title", content: "Administration — SHOPLAY" }, { property: "og:description", content: "Gestion privée des prix SHOPLAY." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }, { name: "robots", content: "noindex" }] }), component: Admin });
function Admin() {
  const { lang } = useLang(); const ar = lang === "ar";
  const queryClient = useQueryClient(); const read = useServerFn(adminPrices); const mutate = useServerFn(changePrice);
  const query = useQuery({ queryKey: ["admin-prices"], queryFn: () => read(), retry: false });
  const [values, setValues] = useState<Record<string, string>>({}); const [busy, setBusy] = useState<string | null>(null); const [message, setMessage] = useState("");
  async function act(id: string, action: "save" | "publish" | "hide") {
    setBusy(id); setMessage("");
    try { await mutate({ data: { id, action, price: action === "save" ? Number(values[id]) : undefined } }); await Promise.all([queryClient.invalidateQueries({ queryKey: ["admin-prices"] }), queryClient.invalidateQueries({ queryKey: ["published-prices"] })]); setMessage(ar ? "تم التحديث" : "Mise à jour enregistrée"); }
    catch { setMessage(ar ? "تعذر التحديث؛ تحقق من السعر والصلاحية" : "Échec : vérifiez le prix et votre accès."); } finally { setBusy(null); }
  }
  return <main className="mx-auto max-w-6xl px-4 py-8" data-identity-user={query.data?.userId ?? ""}>
    <div className="mb-6 flex items-center justify-between"><h1 className="font-display text-2xl font-bold">{ar ? "إدارة الأسعار" : "Administration des prix"}</h1><Button variant="outline" size="icon" aria-label={ar ? "تحديث" : "Actualiser"} onClick={() => query.refetch()}><RefreshCw /></Button></div>
    {query.isPending ? <p>{ar ? "جار التحميل" : "Chargement…"}</p> : query.isError ? <p role="alert">{ar ? "تعذر تحميل الأسعار" : "Chargement impossible"}</p> : !query.data?.allowed ? <p>{ar ? "هذه الصفحة للمدير المخوّل فقط؛ لم تُمنح صلاحية الإدارة لهذا الحساب." : "Accès réservé aux administrateurs autorisés. Ce compte ne possède pas ce rôle."}</p> : <>
    <p className="mb-5 text-sm text-muted-foreground">{ar ? "السعر بالدرهم. حفظ المسودة لا ينشرها؛ النشر يعرض آخر سعر محفوظ للزوار." : "Prix en DH. Une sauvegarde reste privée ; publier affiche le dernier prix enregistré."}</p>
    {message && <p role="status" className="mb-4 text-sm">{message}</p>}
    <div className="overflow-x-auto"><table className="w-full min-w-[650px] text-start text-sm"><thead><tr className="border-b border-border text-muted-foreground"><th className="p-3 text-start">{ar ? "المنتج والفئة" : "Produit / format"}</th><th className="p-3 text-start">{ar ? "السعر الفعلي" : "Prix réel (DH)"}</th><th className="p-3 text-start">{ar ? "منشور" : "Publié"}</th><th className="p-3 text-start">{ar ? "الإجراءات" : "Actions"}</th></tr></thead><tbody>{products.map((product) => {
      const draft = query.data.drafts.find((row) => row.format_id === product.id); const published = query.data.published.find((row) => row.format_id === product.id); const value = values[product.id] ?? (draft ? String(draft.price) : "");
      return <tr key={product.id} className="border-b border-border"><td className="p-3 font-medium">{ar ? product.nameAr : product.name}</td><td className="p-3"><input type="number" step="0.01" min="0.01" aria-label={`${ar ? "سعر" : "Prix"} ${product.name}`} value={value} onChange={(e) => setValues((v) => ({ ...v, [product.id]: e.target.value }))} className="h-9 w-28 rounded-md border border-input bg-background px-2" /></td><td className="p-3">{published ? `${published.price} DH` : (ar ? "غير منشور" : "Non publié")}</td><td className="p-3"><div className="flex gap-2"><Button size="icon" variant="outline" aria-label={`${ar ? "حفظ" : "Sauvegarder"} ${product.id}`} disabled={busy !== null || !validPrice(Number(values[product.id]))} onClick={() => act(product.id, "save")}><Save /></Button><Button size="icon" aria-label={`${ar ? "نشر" : "Publier"} ${product.id}`} disabled={busy !== null || !draft || (values[product.id] !== undefined && Number(values[product.id]) !== Number(draft.price))} onClick={() => act(product.id, "publish")}><Upload /></Button><Button size="icon" variant="outline" aria-label={`${ar ? "إخفاء" : "Masquer"} ${product.id}`} disabled={busy !== null || !published} onClick={() => act(product.id, "hide")}><EyeOff /></Button></div></td></tr>;
    })}</tbody></table></div></>}
  </main>;
}