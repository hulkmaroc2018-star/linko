import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Check, Info, Minus, Plus, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { products, useCart, type Product } from "@/lib/store";
import { useLang } from "@/lib/i18n";
import { productDetails } from "@/lib/product-details";
import { getProductId, groupProductFormats } from "@/lib/product-options";
import { regionalInfo } from "@/lib/regional-catalog";
import { gameTopupInfo } from "@/lib/game-topups";
import { idTopupRequirements } from "@/lib/id-topup-requirements";
import { usePrices } from "@/lib/price-context";
import gamesImage from "@/assets/offers-games.jpg";
import giftsImage from "@/assets/offers-gifts.jpg";
import subscriptionsImage from "@/assets/offers-subscriptions.jpg";

export const Route = createFileRoute("/produits/$productId")({
  head: ({ params }) => {
    const product = products.find((p) => p.id === params.productId);
    const title = product ? `${productDetails[getProductId(product)]?.brand ?? product.name} — SHOPLAY` : "Produit introuvable — SHOPLAY";
    const description = product ? `${product.name} sur SHOPLAY. Cartes, recharges et abonnements au Maroc.` : "Ce produit n’est pas disponible dans le catalogue SHOPLAY.";
    return { meta: [
      { title }, { name: "description", content: description },
      { property: "og:title", content: title }, { property: "og:description", content: description },
      { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
    ] };
  },
  component: ProductPage,
});

function ProductPage() {
  const { productId } = Route.useParams();
  const { lang, t } = useLang();
  const product = products.find((p) => p.id === productId);
  if (!product) return <main className="mx-auto max-w-6xl px-4 py-12"><h1 className="mb-6 text-2xl font-bold">{lang === "ar" ? "المنتج غير موجود" : "Produit introuvable"}</h1><Button asChild><Link to="/">{t("home")}</Link></Button></main>;
  return <ProductDetails key={product.id} product={product} />;
}

function ProductDetails({ product }: { product: Product }) {
  const { lang, t } = useLang();
  const ar = lang === "ar";
  const { add, setOpen } = useCart();
  const { priceFor } = usePrices();
  const [quantity, setQuantity] = useState(1);
  const [selectedId, setSelectedId] = useState(product.id);
  const selected = products.find((item) => item.id === selectedId) ?? product;
  const price = priceFor(selected.id);
  const group = groupProductFormats(products).find((item) => item.id === getProductId(product));
  const formats = group?.formats ?? [product];
  const requirements = idTopupRequirements[getProductId(product)];
   const gameTopup = gameTopupInfo[getProductId(product)];
   const region = gameTopup ?? regionalInfo[getProductId(product)];
  const regionalSiblings = groupProductFormats(products.filter((item) => item.familyId && item.familyId === product.familyId));
  const name = ar ? group?.nameAr ?? product.nameAr : group?.name ?? product.name;
  const details = productDetails[selected.id];
  const related = groupProductFormats(products.filter((p) => p.cat === product.cat && getProductId(p) !== getProductId(product))).slice(0, 4);
  const image = product.cat === "games" ? gamesImage : product.cat === "gifts" ? giftsImage : subscriptionsImage;
  const category = product.cat === "games" ? "games" : product.cat === "gifts" ? "gifts" : "subs";
  const to = product.cat === "games" ? "/" : product.cat === "gifts" ? "/cartes-cadeaux" : "/abonnements";
  return (
    <main className="mx-auto max-w-6xl px-4 py-6 md:py-10">
      <nav aria-label={ar ? "مسار الصفحة" : "Fil d’Ariane"} className="mb-6 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
        <Link to="/" className="hover:text-primary">{t("home")}</Link><span>/</span><Link to={to} className="hover:text-primary">{t(category)}</Link><span>/</span><span className="text-foreground">{name}</span>
      </nav>
      <div className="grid gap-8 md:grid-cols-2 md:items-start md:gap-12">
        <div className="relative aspect-[4/3] overflow-hidden rounded-lg bg-secondary">
          <img src={image} alt="" width={1536} height={768} className="h-full w-full object-cover object-right" />
          <span className="absolute bottom-4 start-4 bg-background/90 px-3 py-2 text-sm font-semibold">{t(category)}</span>
        </div>
        <div>
          <p className="mb-3 text-xs font-semibold text-primary">SHOPLAY</p>
          <h1 className="break-words font-display text-2xl font-bold md:text-3xl">{name}</h1>
          {region && <p className="mt-2 text-sm font-semibold">{region.flag} {ar ? region.nameAr : region.name}</p>}
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{ar ? details?.descriptionAr : details?.description}</p>
          {requirements && <section className="mt-5 border-s-2 border-primary ps-4" aria-label={ar ? "بيانات الشحن" : "Identifiants de recharge"}>
            <h2 className="text-sm font-semibold">{ar ? "الشحن عبر ID" : "Recharge par ID"}</h2>
            <p className="mt-2 text-sm">{(ar ? requirements.identifiersAr : requirements.identifiers).join(" · ")}</p>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{ar ? requirements.noteAr : requirements.note}</p>
          </section>}
          {regionalSiblings.length > 1 && <div className="mt-5 flex flex-wrap gap-2" aria-label={ar ? "منتجات المناطق" : "Produits régionaux"}>{regionalSiblings.map((item) => <Button key={item.id} variant={item.id === getProductId(product) ? "secondary" : "outline"} size="sm" asChild><Link to="/produits/$productId" params={{ productId: item.id }}>{regionalInfo[item.id]?.flag} {item.name}</Link></Button>)}</div>}
          <div className="mt-6 border-y border-border py-4">
            <p className="mb-3 text-sm font-semibold">{ar ? (product.cat === "subs" ? "الباقة والمدة" : "قيمة البطاقة أو الشحن") : (product.cat === "subs" ? "Formule et durée" : "Valeur de la carte ou recharge")}</p>
            <div className={gameTopup ? "grid grid-cols-3 gap-2" : "flex flex-wrap gap-2"} role="group" aria-label={ar ? "اختيار الفئة" : "Choisir un format"}>
              {formats.map((format) => <Button key={format.id} variant="outline" aria-pressed={selectedId === format.id} onClick={() => setSelectedId(format.id)} className={`relative h-auto min-h-16 min-w-0 max-w-full whitespace-normal px-2 py-3 text-center ${selectedId === format.id ? "border-primary bg-primary/10" : ""}`}>
                {selectedId === format.id && <Check className="absolute end-1 top-1 size-3 text-primary" />}<span dir={ ["pubg", "cod", "fc-mobile"].includes(getProductId(product)) ? "ltr" : undefined}>{ar ? productDetails[format.id]?.formatAr : productDetails[format.id]?.format}</span>
              </Button>)}
            </div>
            <dl className="mt-4 space-y-3 text-sm">
              <div className="flex flex-wrap justify-between gap-2"><dt className="text-muted-foreground">{ar ? "المنصة / الخدمة" : "Plateforme / service"}</dt><dd className="font-medium">{details?.brand}</dd></div>
              <div className="flex flex-wrap justify-between gap-2"><dt className="text-muted-foreground">{ar ? "نوع المنتج" : "Type de produit"}</dt><dd>{t(category)}</dd></div>
              <div className="flex flex-wrap justify-between gap-2"><dt className="text-muted-foreground">{ar ? "المنطقة والتفعيل" : "Région et activation"}</dt><dd>{region && `${ar ? region.nameAr : region.name} · `}{ar ? "التفعيل يحتاج للتأكيد" : "Activation à confirmer"}</dd></div>
            </dl>
          </div>
          <p className="mt-6 font-display text-2xl font-bold text-primary">{price === null ? (ar ? "غير متاح حالياً" : "Indisponible actuellement") : `${price} DH / ${ar ? "وحدة" : "unité"}`}</p>
          <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
            <label htmlFor="product-quantity" className="font-semibold">{ar ? "الكمية" : "Quantité"}</label>
            <div className="flex items-center gap-1" dir="ltr">
              <Button variant="outline" size="icon" disabled={quantity <= 1} aria-label={ar ? "تقليل الكمية" : "Diminuer la quantité"} onClick={() => setQuantity((q) => q - 1)}><Minus /></Button>
              <input id="product-quantity" type="number" min={1} step={1} value={quantity} onChange={(event) => { const value = Number(event.target.value); if (Number.isSafeInteger(value) && value >= 1) setQuantity(value); }} className="h-9 w-16 rounded-md border border-input bg-background text-center text-foreground" />
              <Button variant="outline" size="icon" aria-label={ar ? "زيادة الكمية" : "Augmenter la quantité"} onClick={() => setQuantity((q) => q + 1)}><Plus /></Button>
            </div>
          </div>
          <div className="mt-6 flex justify-between border-t border-border pt-4 font-semibold"><span>{t("total")}</span><span>{price === null ? "—" : `${quantity * price} DH`}</span></div>
          <Button size="lg" disabled={price === null} className="mt-5 w-full" onClick={() => { if (price === null) return; add(selected.id, quantity); setOpen(true); }}><ShoppingBag />{ar ? "أضف إلى السلة" : "Ajouter au panier"}</Button>
          <Button variant="link" asChild className="mt-3 px-0"><Link to={to}><ArrowLeft />{t(category)}</Link></Button>
        </div>
      </div>
      <section className="mt-10 border-y border-border py-6">
        <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold"><Info className="size-5 text-primary" />{ar ? "معلومات المنتج" : "Informations produit"}</h2>
        <p className="max-w-3xl text-sm leading-relaxed text-muted-foreground">{ar ? "المنطقة، التوفر وطريقة التسليم تحتاج للتأكيد قبل الشراء." : "Région, disponibilité et mode de livraison à confirmer avant achat."}</p>
        {product.cat === "games" && <p className="mt-3 text-sm text-muted-foreground">{ar ? "متطلبات معرف اللاعب تختلف حسب اللعبة وطريقة الشحن؛ لا تشارك كلمة مرور حسابك." : "Les identifiants nécessaires dépendent du jeu et du mode de recharge. Ne partagez jamais votre mot de passe."}</p>}
      </section>
      <section className="mt-8">
        <h2 className="mb-5 font-display text-xl font-semibold">{ar ? "منتجات من نفس القسم" : "Dans la même catégorie"}</h2>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {related.map((item) => <Link key={item.id} to="/produits/$productId" params={{ productId: item.id }} className="overflow-hidden rounded-lg border border-border bg-card transition-colors hover:border-primary">
            <div className="flex aspect-[2/1] items-center justify-center bg-secondary text-3xl" aria-hidden="true">{item.formats[0]?.emoji}</div>
            <div className="p-3"><h3 className="min-h-10 text-sm font-semibold">{ar ? item.nameAr : item.name}</h3><p className="mt-2 font-semibold text-primary">{(() => { const prices = item.formats.map((format) => priceFor(format.id)).filter((value): value is number => value !== null); return prices.length ? `${Math.min(...prices)} DH` : (ar ? "قريباً" : "Bientôt"); })()}</p></div>
          </Link>)}
        </div>
      </section>
    </main>
  );
}