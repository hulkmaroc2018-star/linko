import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/i18n";
import { ProductGrid } from "@/lib/store";
import { OffersSlider } from "@/components/offers-slider";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SHOPLAY — Recharges de jeux au Maroc" },
      { name: "description", content: "Recharges Free Fire, PUBG, COD, Fortnite, Roblox en DH. Livraison instantanée." },
      { property: "og:title", content: "SHOPLAY — Recharges de jeux" },
      { property: "og:description", content: "Recharges de jeux livrées instantanément au Maroc." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  const { lang } = useLang();
  return (
    <>
      <div className="pt-5"><OffersSlider /></div>
      <main className="mx-auto max-w-6xl px-4 pb-12 pt-4">
        <h2 className="mb-6 font-display text-2xl font-bold">{lang === "ar" ? "منتجاتنا" : "Nos produits"}</h2>
        <div className="space-y-10">
          {([
            { cat: "games", title: "Recharges de jeux", titleAr: "شحن الألعاب", to: "/" },
            { cat: "gifts", title: "Cartes cadeaux", titleAr: "بطاقات الهدايا", to: "/cartes-cadeaux" },
            { cat: "subs", title: "Abonnements", titleAr: "الاشتراكات", to: "/abonnements" },
          ] as const).map((section) => <section key={section.cat} className="border-t border-border pt-5">
            <div className="mb-4 flex items-center justify-between gap-2"><h3 className="font-display text-base font-semibold">{lang === "ar" ? section.titleAr : section.title}</h3>{section.cat !== "games" && <Button variant="link" size="sm" asChild><Link to={section.to}>{lang === "ar" ? "عرض الكل" : "Voir tout"}<ArrowRight className="rtl:rotate-180" /></Link></Button>}</div>
            <ProductGrid cat={section.cat} compact />
          </section>)}
        </div>
      </main>
    </>
  );
}
