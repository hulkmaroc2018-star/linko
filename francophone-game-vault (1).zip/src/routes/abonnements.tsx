import { createFileRoute } from "@tanstack/react-router";
import { useLang } from "@/lib/i18n";
import { PageTitle, ProductGrid } from "@/lib/store";

export const Route = createFileRoute("/abonnements")({
  head: () => ({
    meta: [
      { title: "Abonnements — SHOPLAY" },
      { name: "description", content: "Spotify, Netflix, Shahid, Game Pass, PS Plus et YouTube Premium en DH." },
      { property: "og:title", content: "Abonnements — SHOPLAY" },
      { property: "og:description", content: "Cartes d'abonnement streaming et gaming au Maroc." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});

function Page() {
  const { t } = useLang();
  return (
    <>
      <PageTitle title={t("subs")} sub={t("subsSub")} />
      <main className="mx-auto max-w-6xl px-4 py-12"><ProductGrid cat="subs" /></main>
    </>
  );
}
