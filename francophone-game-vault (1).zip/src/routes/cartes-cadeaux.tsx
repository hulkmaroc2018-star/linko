import { createFileRoute } from "@tanstack/react-router";
import { useLang } from "@/lib/i18n";
import { PageTitle, ProductGrid } from "@/lib/store";

export const Route = createFileRoute("/cartes-cadeaux")({
  head: () => ({
    meta: [
      { title: "Cartes cadeaux — SHOPLAY" },
      { name: "description", content: "Cartes PSN, Steam, Google Play, Xbox, App Store et Nintendo en DH." },
      { property: "og:title", content: "Cartes cadeaux — SHOPLAY" },
      { property: "og:description", content: "Codes cadeaux de jeux livrés instantanément." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});

function Page() {
  const { t } = useLang();
  return (
    <>
      <PageTitle title={t("gifts")} sub={t("giftsSub")} />
      <main className="mx-auto max-w-6xl px-4 py-12"><ProductGrid cat="gifts" /></main>
    </>
  );
}
