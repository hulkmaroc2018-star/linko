import { expect, it } from "vitest";
import { actualPrice, validPrice } from "@/lib/prices";
it("never substitutes a demo price for an unpublished format", () => { expect(actualPrice({}, "psn-fr-10")).toBeNull(); });
it("uses only a published actual price", () => { expect(actualPrice({ "psn-fr-10": 123.45 }, "psn-fr-10")).toBe(123.45); });
it("rejects nonpositive or sub-cent prices", () => { expect(validPrice(0)).toBe(false); expect(validPrice(-1)).toBe(false); expect(validPrice(12.345)).toBe(false); expect(validPrice(12.34)).toBe(true); });