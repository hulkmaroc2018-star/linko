import { describe, expect, it } from "vitest";
import { products } from "@/lib/store";
import { groupProductFormats } from "@/lib/product-options";
import { groupProductsByFamily } from "@/lib/product-families";
import { addCartQuantity } from "@/lib/cart-quantity";

describe("Product denomination selection", () => {
  it("keeps game additions keyed by format without an account country", () => {
    const freeFire = products.find((item) => item.id === "ff");
    expect(freeFire?.price).toBe(49);
    expect(addCartQuantity({}, "ff", 2)).toEqual({ ff: 2 });
  });
  it("groups all PSN denominations in one product, not with PS Plus", () => {
    const groups = groupProductFormats(products);
    expect(groups.filter((item) => item.id === "psn")).toHaveLength(1);
    expect(groups.find((item) => item.id === "psn")?.formats.map((item) => item.id)).toEqual(["psn", "psn-10", "psn-50"]);
    expect(groups.find((item) => item.id === "psplus")?.formats.map((item) => item.id)).toEqual(["psplus"]);
  });
  it("preserves the existing 20 euro price and separate cart quantities", () => {
    const psn = products.find((item) => item.id === "psn");
    expect(psn?.price).toBe(229);
    expect(addCartQuantity({ psn: 2 }, "psn-50", 3)).toEqual({ psn: 2, "psn-50": 3 });
  });
  it("keeps the new PSN denominations in the PlayStation family", () => {
    expect(groupProductsByFamily(products).find((item) => item.id === "playstation")?.products.filter((item) => !item.familyId).map((item) => item.id)).toEqual(["psn", "psn-10", "psn-50", "psplus"]);
  });
});