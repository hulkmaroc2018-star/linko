import { describe, expect, it } from "vitest";
import { addCartQuantity } from "@/lib/cart-quantity";

describe("Product quantities", () => {
  it("adds the selected number of units", () => {
    expect(addCartQuantity({}, "ff", 3)).toEqual({ ff: 3 });
  });
  it("accumulates units of the same format", () => {
    expect(addCartQuantity({ ff: 3 }, "ff", 2)).toEqual({ ff: 5 });
  });
  it("does not add invalid quantities", () => {
    for (const quantity of [0, -1, 1.5, NaN]) {
      expect(addCartQuantity({ ff: 3 }, "ff", quantity)).toEqual({ ff: 3 });
    }
  });
});