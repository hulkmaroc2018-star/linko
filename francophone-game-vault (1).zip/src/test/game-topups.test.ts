import { describe, expect, it } from "vitest";
import { products } from "@/lib/store";
import { groupProductFormats } from "@/lib/product-options";
import { gameTopupInfo } from "@/lib/game-topups";
import { idTopupRequirements } from "@/lib/id-topup-requirements";
import { groupProductsByFamily } from "@/lib/product-families";
import { productDetails } from "@/lib/product-details";
import { actualPrice } from "@/lib/prices";
import { addCartQuantity } from "@/lib/cart-quantity";

describe("Grouped game top-ups", () => {
  it("groups the six requested ID games with independent denomination IDs", () => {
    const ids = ["ff", "pubg", "mobile-legends", "fc-mobile", "cod", "jawaker"];
    const groups = groupProductFormats(products);
    for (const id of ids) {
      expect(groups.filter((group) => group.id === id)).toHaveLength(1);
      expect(groups.find((group) => group.id === id)?.formats.length).toBeGreaterThan(1);
      expect(idTopupRequirements[id]?.identifiers.length).toBeGreaterThan(0);
    }
    expect(new Set(products.map((p) => p.id)).size).toBe(products.length);
    expect(groupProductsByFamily(products).flatMap((family) => family.products)).toHaveLength(products.length);
  });
  it("requires both Mobile Legends identifiers, not a password", () => {
    expect(idTopupRequirements["mobile-legends"]?.identifiers).toEqual(["User ID", "Zone ID"]);
    expect(Object.values(idTopupRequirements).flatMap((game) => game.identifiers)).not.toContain("Password");
  });
  it("keeps FC Mobile separate from the legacy EA FC product", () => {
    const group = groupProductFormats(products).find((game) => game.id === "fc-mobile");
    expect(group?.formats.map((format) => productDetails[format.id]?.format)).toEqual(["40 FC Points", "100 FC Points", "520 FC Points", "1070 FC Points", "2200 FC Points", "5750 FC Points", "12000 FC Points"]);
    expect(group?.formats.some((format) => format.id === "fc")).toBe(false);
  });
  it("keeps Activision CP separate from Garena quantities", () => {
    const group = groupProductFormats(products).find((game) => game.id === "cod");
    expect(group?.formats.map((format) => productDetails[format.id]?.format)).toEqual(["80 CP", "420 CP", "880 CP", "2400 CP", "5000 CP", "10800 CP", "21600 CP", "32400 CP", "43200 CP", "54000 CP"]);
  });
  it("uses verified Jawaker token totals without inventing Basha denominations", () => {
    const group = groupProductFormats(products).find((game) => game.id === "jawaker");
    expect(group?.formats.map((format) => productDetails[format.id]?.format)).toEqual(["4250 tokens", "32500 tokens", "70000 tokens", "150000 tokens", "230000 tokens", "400000 tokens", "525000 tokens", "805000 tokens"]);
    expect(products.some((format) => format.id.includes("basha"))).toBe(false);
  });
  it("groups the six screenshot diamond amounts into Free Fire", () => {
    const groups = groupProductFormats(products);
    expect(groups.filter((group) => group.id === "ff")).toHaveLength(1);
    expect(groups.find((group) => group.id === "ff")?.formats.map((item) => productDetails[item.id]?.format)).toEqual(["50 diamants", "100 diamants", "210 diamants", "530 diamants", "1080 diamants", "2200 diamants"]);
    expect(gameTopupInfo["ff"]?.name).toBe("Middle East · ID joueur");
  });
  it("groups Global PUBG base and bonus amounts in one product", () => {
    const groups = groupProductFormats(products);
    expect(groups.filter((group) => group.id === "pubg")).toHaveLength(1);
    expect(groups.find((group) => group.id === "pubg")?.formats.map((item) => productDetails[item.id]?.format)).toEqual(["60 UC", "300 + 25 UC", "600 + 60 UC", "1500 + 300 UC", "3000 + 850 UC", "6000 + 2100 UC", "12000 + 4200 UC"]);
    expect(gameTopupInfo["pubg"]?.name).toBe("Global");
  });
  it("keeps each selected denomination separate in the cart", () => {
    expect(addCartQuantity({ "ff-50": 2 }, "ff-100", 3)).toEqual({ "ff-50": 2, "ff-100": 3 });
    expect(addCartQuantity({ "pubg-60": 1 }, "pubg", 2)).toEqual({ "pubg-60": 1, pubg: 2 });
  });
  it("does not give new denominations a price without publication", () => {
    expect(actualPrice({}, "ff-50")).toBeNull();
    expect(actualPrice({}, "pubg-60")).toBeNull();
  });
});