import { describe, expect, it } from "vitest";
import { products } from "@/lib/store";
import { groupProductFormats } from "@/lib/product-options";
import { groupProductsByFamily } from "@/lib/product-families";
import { addCartQuantity } from "@/lib/cart-quantity";

describe("Regional product formats", () => {
  it("groups denominations separately for France and USA", () => {
    const groups = groupProductFormats(products);
    expect(groups.find((group) => group.id === "psn-fr")?.formats.map((item) => item.id)).toEqual(["psn-fr", "psn-fr-10", "psn-fr-50"]);
    expect(groups.find((group) => group.id === "psn-us")?.formats.map((item) => item.id)).toEqual(["psn-us", "psn-us-10", "psn-us-50"]);
  });
  it("keeps regional formats in the PlayStation family", () => {
    const ids = groupProductsByFamily(products).find((family) => family.id === "playstation")?.products.map((item) => item.id);
    expect(ids).toContain("psn-fr-50");
    expect(ids).toContain("psn-us-50");
    expect(ids).toContain("psplus");
  });
  it("preserves existing prices and separates regional cart entries", () => {
    expect(products.find((item) => item.id === "psn")?.price).toBe(229);
    expect(products.find((item) => item.id === "psn-50")?.price).toBe(569);
    expect(addCartQuantity({ "psn-fr-10": 2 }, "psn-us-10", 1)).toEqual({ "psn-fr-10": 2, "psn-us-10": 1 });
  });
});