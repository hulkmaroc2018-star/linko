import { describe, expect, it } from "vitest";
import { groupProductsByFamily } from "@/lib/product-families";

describe("Product families", () => {
  it("keeps PSN formats together and separate from Steam", () => {
    const groups = groupProductsByFamily([{ id: "psn", price: 229 }, { id: "steam", price: 119 }, { id: "psplus", price: 99 }]);
    expect(groups.find((group) => group.id === "playstation")?.products).toEqual([{ id: "psn", price: 229 }, { id: "psplus", price: 99 }]);
    expect(groups.find((group) => group.id === "steam")?.products).toEqual([{ id: "steam", price: 119 }]);
  });
  it("keeps Xbox cards with Xbox subscriptions", () => {
    const groups = groupProductsByFamily([{ id: "gamepass" }, { id: "xbox" }, { id: "netflix" }]);
    expect(groups.find((group) => group.id === "xbox")?.products.map((product) => product.id)).toEqual(["gamepass", "xbox"]);
  });
});