import { useCallback, useEffect, useState } from "react";
import useEmblaCarousel from "embla-carousel-react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Pause, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/i18n";
import gamesImage from "@/assets/offers-games.jpg";
import giftsImage from "@/assets/offers-gifts.jpg";
import subscriptionsImage from "@/assets/offers-subscriptions.jpg";

const offers = [
  { image: gamesImage, title: "Free Fire · PUBG Mobile", titleAr: "فري فاير · ببجي موبايل", sub: "Diamants, UC et points pour vos jeux favoris.", subAr: "جواهر وشدات ونقاط لألعابك المفضلة.", to: "/" as const, hash: "ff", label: "Voir les recharges", labelAr: "تصفح شحن الألعاب" },
  { image: giftsImage, title: "PSN · Steam · Xbox", titleAr: "بلايستيشن · ستيم · إكس بوكس", sub: "Vos cartes cadeaux gaming, au même endroit.", subAr: "بطاقات الهدايا لألعابك في مكان واحد.", to: "/cartes-cadeaux" as const, hash: "", label: "Voir les cartes", labelAr: "تصفح البطاقات" },
  { image: subscriptionsImage, title: "Spotify · Netflix", titleAr: "سبوتيفاي · نتفليكس", sub: "Retrouvez vos abonnements préférés.", subAr: "اكتشف اشتراكاتك المفضلة.", to: "/abonnements" as const, hash: "", label: "Voir les abonnements", labelAr: "تصفح الاشتراكات" },
];

export function OffersSlider() {
  const { lang } = useLang();
  const ar = lang === "ar";
  const [viewportRef, api] = useEmblaCarousel({ loop: true, direction: ar ? "rtl" : "ltr" });
  const [selected, setSelected] = useState(0);
  const [paused, setPaused] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const onSelect = useCallback(() => { if (api) setSelected(api.selectedScrollSnap()); }, [api]);

  useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReducedMotion(query.matches);
    update();
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);

  useEffect(() => {
    if (!api) return;
    onSelect();
    api.on("select", onSelect).on("reInit", onSelect);
    return () => { api.off("select", onSelect).off("reInit", onSelect); };
  }, [api, onSelect]);

  useEffect(() => {
    if (!api || paused || hovered || reducedMotion) return;
    const timer = window.setInterval(() => { if (!document.hidden) api.scrollNext(); }, 5000);
    return () => window.clearInterval(timer);
  }, [api, paused, hovered, reducedMotion, selected]);

  return (
    <section aria-label={ar ? "عروض حصرية" : "Offres exclusives"} aria-roledescription="carousel" className="mx-auto max-w-6xl px-4 pb-8" onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)} onFocusCapture={() => setHovered(true)} onBlurCapture={(event) => { if (!event.currentTarget.contains(event.relatedTarget)) setHovered(false); }}>
      <div className="mb-3 flex items-center justify-between">
        <h2 className="font-display text-lg font-semibold">{ar ? "عروض حصرية" : "Offres exclusives"}</h2>
        <span className="text-xs text-muted-foreground" dir="ltr">{selected + 1} / {offers.length}</span>
      </div>
      <div ref={viewportRef} className="overflow-hidden rounded-lg border border-border bg-card">
        <div className="flex touch-pan-y">
          {offers.map((offer, index) => (
            <div key={offer.to} role="group" aria-roledescription="slide" aria-label={`${index + 1} / ${offers.length}`} aria-hidden={selected !== index} className="offer-slide relative min-w-0 flex-[0_0_100%] overflow-hidden">
              <img src={offer.image} alt="" width={1536} height={768} loading={index === 0 ? "eager" : "lazy"} className="absolute inset-0 h-full w-full object-cover object-right" />
              <div className="offer-content relative z-10 flex h-full flex-col justify-center p-6 md:p-12">
                <span className="mb-3 text-xs font-semibold text-primary">SHOPLAY</span>
                <h3 className="max-w-sm font-display text-2xl font-bold md:text-4xl">{ar ? offer.titleAr : offer.title}</h3>
                <p className="mt-3 max-w-xs text-sm text-muted-foreground md:text-base">{ar ? offer.subAr : offer.sub}</p>
                <Button asChild className="mt-6 self-start">
                  <Link to={offer.to} hash={offer.hash} tabIndex={selected === index ? 0 : -1}>{ar ? offer.labelAr : offer.label}{ar ? <ArrowLeft /> : <ArrowRight />}</Link>
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between" dir="ltr">
        <div className="flex gap-1">
          <Button variant="outline" size="icon" aria-label={ar ? "العرض السابق" : "Offre précédente"} onClick={() => api?.scrollPrev()}><ArrowLeft /></Button>
          <Button variant="outline" size="icon" aria-label={ar ? "العرض التالي" : "Offre suivante"} onClick={() => api?.scrollNext()}><ArrowRight /></Button>
        </div>
        <div className="flex gap-1">
          {offers.map((offer, index) => <Button key={offer.to} variant="ghost" size="icon" aria-label={ar ? `العرض ${index + 1}` : `Offre ${index + 1}`} aria-current={selected === index ? "true" : undefined} onClick={() => api?.scrollTo(index)}><span className={`h-1.5 w-5 rounded-full ${selected === index ? "bg-primary" : "bg-muted-foreground/40"}`} /></Button>)}
        </div>
        <Button variant="ghost" size="icon" disabled={reducedMotion} aria-label={paused ? (ar ? "تشغيل العروض" : "Reprendre les offres") : (ar ? "إيقاف العروض" : "Mettre en pause")} onClick={() => setPaused(!paused)}>{paused || reducedMotion ? <Play /> : <Pause />}</Button>
      </div>
    </section>
  );
}