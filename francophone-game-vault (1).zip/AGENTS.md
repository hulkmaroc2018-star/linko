<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

- Use the existing Embla library for the home offers carousel, keeping its content bilingual and navigation keyboard-accessible to preserve consistent storefront behavior.
- Product detail URLs use one dynamic /produits/$productId route backed by the existing catalog; each listed format retains its own ID and price, and cart quantities count units of that format.
- Keep bilingual product specifications in a browser-safe product-details module; show unknown activation, duration or region as unconfirmed instead of importing competitors’ inventory claims.
- Use the shared browser-safe product-family mapping for catalog and menu grouping, preserving each format's catalog ID and price across categories.
- Group denominations by productId in the browser-safe product-options module for one storefront entry per product; keep selection and cart entries keyed by format ID so distinct services never merge.
- Define regional demonstration SKUs in the browser-safe regional-catalog module; use familyId for shared brand grouping and productId for separate region-specific denomination groups, preserving legacy IDs and prices.
- Visitor prices come only from published_prices through the shared price provider; never fall back to static catalog amounts, including metadata, related products and cart totals.
- Price administration uses verified Lovable workspace identity and protected user_roles rows; save drafts separately and publish through role-checked database functions, never self-assign administrators.
- Keep game top-up denominations and regional descriptions in the browser-safe game-topups module; reuse productId grouping and independent format IDs so catalog, details and price administration stay consistent.
- Keep ID delivery requirements in a browser-safe shared module and display them as product specifications, not a supplier login or unimplemented recharge flow; never collect account passwords.
