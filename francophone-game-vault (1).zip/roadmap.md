# Product pages
- [x] Create bilingual pages for all displayed product formats.
- [x] Link catalog and menu products to their pages.
- [x] Verify quantity selection and cart totals.

# Catalog inspiration
- [x] Review comparable stores for product presentation ideas.
- [x] Apply bilingual product specifications and related products without importing unverified prices or availability.
- [x] Verify product details and cart flow on desktop and mobile.

# Storefront grouping
- [x] Restore the prominent home offers slider.
- [x] Group catalog products and menu entries by family without changing formats or prices.
- [x] Verify slider navigation and grouped products on mobile and desktop.

# SEAGM reference and rollback
- [x] Review the provided SEAGM storefront reference.
- [x] Remove the last account-country and research-only denomination changes.
- [x] Verify original denomination and cart behavior, retaining three products per row.

# Regional storefront presentation
- [x] Add regional PSN demonstration products with separate denomination IDs, preserving existing catalog prices.
- [x] Present compact category sections inspired by SEAGM with three products per row and the existing slider.
- [x] Verify regional denominations, cart separation and bilingual mobile presentation.

# Actual price administration
- [x] Add protected price administration using Lovable identity and stored roles.
- [x] Store draft and published prices; expose only explicitly published actual prices to visitors.
- [x] Remove every storefront fallback to demonstration prices and verify unpublished storefront behavior.
- [ ] Grant the requesting account administrator access and verify saving/publishing through the UI — blocked by missing verified workspace identity in the active preview.

# Game top-up denominations
- [x] Group screenshot denominations inside Free Fire (Middle East ID) and PUBG Mobile (Global), preserving independent format IDs and published-only prices.
- [x] Verify bilingual denomination selection, grouping, and mobile presentation.

# ID game catalog
- [x] Research the previously supplied stores for the four remaining ID games and distinguish verified denominations from uncertain services.
- [x] Add and coordinate the six ID game entries with grouped formats, bilingual requirements and published-only prices.
- [x] Test catalog grouping and denomination selection on mobile and desktop.