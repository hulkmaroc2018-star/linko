# Francophone Game Vault

متجر الكتروني ليبيع بطاقات العاب وشحن الاعاب بي فرنسية و عربية فرنسية هيا اساس

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://francophone-game-vault.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/877404b4-bf44-4461-be58-73c2ccbe48bd).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
